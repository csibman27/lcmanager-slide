# README.md

## Date
2024-04-12 

## How to use
Depends on having reveal-md installed - https://github.com/webpro/reveal-md

```
npm install -g reveal-md
reveal-md --theme league slides.md
```	
    
```
reveal-md --theme league slides.md 
```
will open in a browser for presenting.

```
reveal-md --theme league slides.md --static site
```

Will generate a static site in 'site' directory


# Project Slide Tibor Molnar
# lcmanager-slide

# Slide is hosted: http://87.44.17.215:1948/slides.md#/
